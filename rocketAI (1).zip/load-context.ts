import { type PlatformProxy } from 'wrangler';

type Cloudflare = Omit<PlatformProxy<Env>, 'dispose'>;

interface NetlifyContext {
  env?: Record<string, string>;
}

declare module '@remix-run/cloudflare' {
  interface AppLoadContext {
    cloudflare?: Cloudflare;
    netlify?: NetlifyContext;
  }
}
