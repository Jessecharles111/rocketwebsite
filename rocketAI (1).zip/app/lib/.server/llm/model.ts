import { createMistral } from '@ai-sdk/mistral';

export function getMistralModel(apiKey: string, modelId: string = 'mistral-large-latest') {
  const mistral = createMistral({
    apiKey,
  });

  return mistral(modelId);
}

export const availableMistralModels = [
  'mistral-large-latest',
  'mistral-vibe-cli',
  'devstral-latest',
  'devstral-large-latest',
  'codestral-latest',
];
