import { env } from 'node:process';

export function getAPIKey(platformEnv?: Env | Record<string, string>) {
  /**
   * The `platformEnv` can be either Cloudflare env or Netlify env.
   * In development the environment variables are available through `env`.
   * In production, it uses platform-specific environment variables.
   */
  return env.MISTRAL_API_KEY || (platformEnv?.MISTRAL_API_KEY as string);
}
