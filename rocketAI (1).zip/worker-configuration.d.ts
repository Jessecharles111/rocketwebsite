interface Env {
  MISTRAL_API_KEY: string;
}
